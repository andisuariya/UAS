## Aplikasi Pengaduan Masyarakat-CI4

Aplikasi ini dikembangan dengan menggunakan PHP Versi 8.1.12 
PHP Framework Codeigniter 4.3.2 MySQL 8.0.32. 

Dikembangkan sebagai project Uji Kompetensi Program 
Keahlian Rekayasa Perangkat Lunak SMK Negeri 2 Kuningan Tahun 2023.

## Petunjuk Instalasi

1. Rename file env menjadi .env (titik env)

2. Ubah bagian

   app.baseURL = ''
 
   Menjadi alamat URL aplikasi anda

3. Ubah environment menjadi production jika akan di online kan

4. Ubah seting database di bagian Database

## Petunjuk Penggunaan

login masyarakat : http://localhost:8080/

User masyarakat : delvi password masyarakat : 111

Login Petugas admin & Non Admin : http://localhost:8080/

User admin : admin password admin : 123

##Jika ada pertanyaan tanyakan saja teman-teman~~
instagram : dlvnstni_
